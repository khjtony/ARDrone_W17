function sayHello(name) {
    alert(name)
}